
#include<iostream>
#include<stack>
using namespace std;
int main(){
    stack<int>st;
    st.push(10);
    st.push(5);
    cout<<"top element "<<st.top()<<endl;
    st.pop();
    cout<<"top element after pop"<<st.top()<<endl;
    return 0;
}